﻿using Bookstore.Communication.Request;

namespace Bookstore.Database;

public static class Db
{
    public static List<Book> Books = new List<Book>();

    public static Book GetBookById(int bookId)
    {

        foreach (var item in Books)
        {
            if (item.Id == bookId)
            {
                return item;
            }
        }

        return null;
    }

    public static bool CreateBook(Book book)
    {
        Random id = new Random();
        book.Id = id.Next(1, 10000);
        
        var isBookAlreadyRegistered = GetBookById(book.Id);

        if (isBookAlreadyRegistered is null)
        {
            Books.Add(book);
            return true;
        }

        return CreateBook(book);

    }

    public static List<Book> GetAllBooks()
    {
        return Books;
    }

    public static bool UpdateBook(int bookId, RequestUpdateBookJson infos)
    {
        var book = GetBookById(bookId);

        if (book is null)
        {
            return false;
        }

        book.Title = infos.Title == "" ? book.Title : infos.Title;
        book.Author = infos.Author == "" ? book.Author : infos.Author;
        book.Gender = infos.Gender == "" ? book.Gender : infos.Gender;
        book.Price = infos.Price == 0 ? book.Price : infos.Price;

        return true;
    }

    public static void DeleteBook(int bookId)
    {
        Books.Remove(GetBookById(bookId));
    }
}
