﻿using Bookstore.Communication.Request;
using Bookstore.Communication.Response;
using Bookstore.Database;
using Microsoft.AspNetCore.Mvc;

namespace Bookstore.Controllers;

public class BookController : BookstoreBaseController
{
    [HttpGet]
    [Route("{id}")]
    [ProducesResponseType(typeof(Book), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public IActionResult GetById([FromRoute] int id)
    {
        var book = Db.GetBookById(id);

        if (book is null)
        {
            return NotFound();
        }

        return Ok(book);
    }

    [HttpPost]
    [ProducesResponseType(typeof(ResponseRegisteredBookJson), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public IActionResult Create([FromBody] RequestRegisterBookJson request)
    {

        var book = new Book()
        {
            Title = request.Title,
            Author = request.Author,
            Gender = request.Gender,
            Price = request.Price,
            QuantityInStock = 0
        };

        if (Db.CreateBook(book))
        {
            var response = new ResponseRegisteredBookJson() { Title = book.Title };

            return Created(string.Empty, response);
        }

        return BadRequest();
    }

    [HttpGet]
    [ProducesResponseType(typeof(List<Book>), StatusCodes.Status200OK)]
    public IActionResult GetAll()
    {
        List<Book> books = Db.GetAllBooks();

        return Ok(books);
    }

    [HttpPut]
    [Route("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public IActionResult Update([FromRoute] int id, [FromBody] RequestUpdateBookJson infos)
    {
        if (Db.UpdateBook(id, infos))
        {
            return NoContent();
        }

        return NotFound();

    }

    [HttpDelete]
    [Route("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public IActionResult Delete([FromRoute] int id)
    {
        Db.DeleteBook(id);

        return NoContent();
    }
}
