﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Bookstore.Controllers;

[Route("[controller]")]
[ApiController]
public class BookstoreBaseController : ControllerBase
{
}
