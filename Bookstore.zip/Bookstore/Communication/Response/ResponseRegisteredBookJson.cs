﻿namespace Bookstore.Communication.Response;

public class ResponseRegisteredBookJson
{
    public string Title { get; set; } = string.Empty;
}
